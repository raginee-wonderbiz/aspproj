using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using login.Authentication;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Data;

// using System.Security.Claims;

namespace login.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<LoginUser> userManager;
        private readonly IConfiguration _configuration;
        private readonly LoginDbContext _context;
        public AuthenticationController(UserManager<LoginUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration, LoginDbContext context)
        {
            this.userManager = userManager;
            _configuration = configuration;
            _context = context;
        }
        


        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Login([FromBody] RegisterModel model)
        {
            Console.Write("Register method............");
            var userExist = await userManager.FindByNameAsync(model.UserName);
            if (userExist != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists" });
            RegisterUser user = new RegisterUser()
            {
                Email = model.Email,
                UserName = model.UserName,
                PasswordHash = model.Password
            };
            try
            {
                Console.Write("New log.............:", user);
                await _context.SaveChangesAsync();
                return Ok(new Response { Status = "Success", Message = "User Created Successfully" });
            }
            catch{
                return Ok(new Response { Status = "Success", Message = "User Unsucessfull" });
            }
            // var result = await userManager.CreateAsync(user, model.Password);
            // if (!result.Succeeded){
            //     return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User not created successfully"});
            // }
            
            
        }
        
        // [HttpGet]
        // public async Task<IActionResult> Login([FromBody] RegisterModel model)
        // {
        //     return await _context.RegisterUsers.ToList();
        // }


        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            var user = await userManager.FindByNameAsync(model.UserName);
            if (user != null && await userManager.CheckPasswordAsync(user, model.Password))
            {
                var userRoles = await userManager.GetRolesAsync(user);

                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

                var token = new JwtSecurityToken(
                    issuer: _configuration["JWT:ValidIssuer"],
                    audience: _configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddHours(3),
                    claims: authClaims,
                    signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token),
                    expiration = token.ValidTo,
                    User = user.UserName
                });
            }
            return Unauthorized();
        }
    }
}