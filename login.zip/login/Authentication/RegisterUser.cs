using Microsoft.AspNetCore.Identity;

namespace login.Authentication
{
    public class RegisterUser: IdentityUser
    {
        
    }
}