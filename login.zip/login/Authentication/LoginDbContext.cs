using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace login.Authentication
{
    public class LoginDbContext: IdentityDbContext<LoginUser>
    {
         #pragma warning disable CS8618
        public LoginDbContext(DbContextOptions<LoginDbContext> options) : base(options) { 

        }

        public DbSet<RegisterUser> RegisterUsers { get; set; }

                protected override void OnModelCreating(ModelBuilder builder)
         {
                base.OnModelCreating(builder);

                
         }
    }
}