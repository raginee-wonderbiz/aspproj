namespace login.Authentication
{
    public class RegRepository
    {
        
    }
}