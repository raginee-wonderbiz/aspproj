namespace login.Authentication
{
    internal class Response
    {
        public string Status { get; set; } = default!;
        public string Message { get; set; } = default!;
    }
}